## multischema-metabase-dashboard-helper
metabase multi tenant (schemas) helper to generate dashboards for all available schemas
